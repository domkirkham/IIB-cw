two_norm(A1, b1)
two_norm(A2, b2)
two_norm(A3, b3)
two_norm(A4, b4)
two_norm(A5, b5)

